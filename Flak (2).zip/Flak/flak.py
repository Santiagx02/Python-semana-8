class libro:
    def __init__(self, titulo, autor, genero,num_paginas):
        self.titulo = titulo
        self.autor = autor
        self.genero= genero
        self.num_paginas= num_paginas

def mostrar_info(self):
    print("Titulo:", self.titulo)
    print("Autor", self.autor)
    print("Gnero:", self.genero)
    print("Número de páginas:", self.num_paginas)

class Libroprestado(libro):
    def __init__ (self, titulo, autor, genero, num_paginas, prestado_a):
        super().__init__(titulo, autor, genero, num_paginas)
        self.prestado_a = prestado_a

    def mostrar_info(Self):
        super().mostrar_info()
        print("Prestado a:", Self.prestado_a)

#Crear objetos de la clase libro
libro1= libro("El codigo Da Vinci", "Dan Brown","Misterio", 624)
Libro2= libro("Cien años de Soledad","Gabriel Garcia Marquez","Realismo Magico",432)

#Mostrar Información de los libros
print("Información del Libro 1:")
libro1.mostrar_info()
print("\nInformación del libro 2:")
Libro2.mostrar_info()

#Crear objetos de la clase Libroprestado
Libroprestado1 = Libroprestado("Python Crash Course", "Eric Matthes", "Programación", 544, "Juan Perez")
Libroprestado2 = Libroprestado("Clean code","Robert C. Martin", "Programación", 464,"María Gómez")

#Mostrar Información De los libros prestados
print("\nInformación del libro prestado 1:")
Libroprestado1.mostrar_info()
print("\nInformación del libro prestado :")
Libroprestado2.mostrar_info()